#pragma once
#include "Point.h"

class Triangle {
private:
	Point a_, b_, c_;
public:
	Triangle();
	Triangle(Point a, Point b, Point c);
	Triangle(const Triangle& other);
	~Triangle();

	void setA(const Point& value);
	void setB(const Point& value);
	void setC(const Point& value);
	Point getA();
	Point getB();
	Point getC();
	bool isTriangle();
	void move(double k);
	double getPerimeter();
	bool isEqual(Triangle& other);
	double getSquare();
};

