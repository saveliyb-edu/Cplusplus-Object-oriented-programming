#include "Point.h"
#include "math.h"

Point::Point() {
	this->setX(0.0);
	this->setY(0.0);
}

Point::Point(double x, double y) {
	this->setX(x);
	this->setY(y);
}

Point::Point(const Point& other) {
	setX(other.x_);
	setY(other.y_);
}

Point::~Point() {}

void Point::setX(double value) {
	this->x_ = value;
}

void Point::setY(double value) {
	this->y_ = value;
}

double Point::getX() {
	return this->x_;
}

double Point::getY() {
	return this->y_;
}

bool Point::isEqual(Point& other){
	return getX() == other.getX() && getY() == other.getY();
}

double Point::getDistance(Point& other) {
	return sqrt(pow(getX() - other.getX(), 2) + pow(getY() - other.getY(), 2));
}

void Point::move(double k) {
	setX(getX() + k);
	setY(getY() + k);
}