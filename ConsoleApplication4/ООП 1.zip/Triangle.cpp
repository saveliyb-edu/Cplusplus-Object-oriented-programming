#include "Triangle.h"
#include "Point.h"
#include <algorithm>
#include <math.h>

using namespace std;

Triangle::Triangle() {
	Point a_(0.0, 0.0);
	Point b_(0.0, 0.0);
	Point c_(0.0, 0.0);

}

Triangle::Triangle(Point a, Point b, Point c) {
	this->setA(a);
	this->setB(b);
	this->setC(c);
}

Triangle::Triangle(const Triangle& other) {
	setA(other.a_);
	setB(other.b_);
	setC(other.c_);
}

Triangle::~Triangle(){}

void Triangle::setA(const Point& value) {
	a_ = value;
}

void Triangle::setB(const Point& value) {
	b_ = value;
}

void Triangle::setC(const Point& value) {
	c_ = value;
}

Point Triangle::getA() {
	return this->a_;
}

Point Triangle::getB() {
	return this->b_;
}

Point Triangle::getC() {
	return this->c_;
}

bool Triangle::isTriangle() {
	double ab = a_.getDistance(b_);
	double ac = a_.getDistance(c_);
	double bc = b_.getDistance(c_);

	return 2 * max(ab, max(ac, bc)) < ab + bc + ac;
}

void Triangle::move(double k) {
	a_.move(k);
	b_.move(k);
	c_.move(k);
}

double Triangle::getPerimeter() {
	return b_.getDistance(c_) + a_.getDistance(c_) + a_.getDistance(b_);
}


bool Triangle::isEqual(Triangle& other){
	return
		(a_.isEqual(other.a_) && b_.isEqual(other.b_) && c_.isEqual(other.c_)) ||
		(a_.isEqual(other.a_) && b_.isEqual(other.c_) && c_.isEqual(other.b_)) ||
		(a_.isEqual(other.b_) && b_.isEqual(other.c_) && c_.isEqual(other.a_)) ||
		(a_.isEqual(other.c_) && b_.isEqual(other.a_) && c_.isEqual(other.b_)) ||
		(a_.isEqual(other.c_) && b_.isEqual(other.b_) && c_.isEqual(other.a_)) ||
		(a_.isEqual(other.b_) && b_.isEqual(other.a_) && c_.isEqual(other.c_));
}

double Triangle::getSquare() {
	return sqrt((getPerimeter() / 2) *
		(getPerimeter() / 2 - a_.getDistance(b_)) *
		(getPerimeter() / 2 - a_.getDistance(c_)) *
		(getPerimeter() / 2 - b_.getDistance(c_)));
}