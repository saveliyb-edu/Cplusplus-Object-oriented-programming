#pragma once

class Point {
private:
	double x_;
	double y_;
public:
	Point();
	Point(double x, double y);
	Point(const Point& other);
	~Point();

	void setX(double x);
	void setY(double y);
	double getX();
	double getY();
	bool isEqual(Point& other);
	double getDistance(Point& other);
	void move(double k);
};